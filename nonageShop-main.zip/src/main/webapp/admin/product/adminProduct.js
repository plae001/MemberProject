
function go_search(){
    document.formm.action = "NonageServlet?command=admin_product_search";
    document.formm.submit();
}