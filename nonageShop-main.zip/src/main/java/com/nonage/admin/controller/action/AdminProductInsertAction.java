package com.nonage.admin.controller.action;

import com.nonage.admin.controller.dao.AdminProductDAO;
import com.nonage.admin.controller.dto.AdminProductVO;
import com.nonage.controller.action.Action;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

public class AdminProductInsertAction implements Action {
    @Override
    public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = "NonageServlet?command=admin_product_list";  // 상품 목록 페이지로 포워딩


        String kindStr = req.getParameter("kind");
        String name = req.getParameter("name");
        int price1 = Integer.parseInt(req.getParameter("price1"));
        int price2 = Integer.parseInt(req.getParameter("price2"));
        int price3 = Integer.parseInt(req.getParameter("price3"));
        String content = req.getParameter("content");
        String useyn = req.getParameter("useyn") != null ? "Y" : "N";
        String bestyn = req.getParameter("bestyn") != null ? "Y" : "N";

        // kind 값 숫자변환
        int kind = 0;
        if ("Heels".equals(kindStr)) {
            kind = 1;
        } else if ("Boots".equals(kindStr)) {
            kind = 2;
        } else if ("Sandals".equals(kindStr)) {
            kind = 3;
        } else if ("Sneakers".equals(kindStr)) {
            kind = 4;
        }

        String image = ""; // 이미지 저장 로직 추가 필요


        AdminProductVO adminProductVO = new AdminProductVO();
        adminProductVO.setKind(String.valueOf(kind));
        adminProductVO.setName(name);
        adminProductVO.setPrice1(price1);
        adminProductVO.setPrice2(price2);
        adminProductVO.setPrice3(price3);
        adminProductVO.setContent(content);
        adminProductVO.setUseyn(useyn);
        adminProductVO.setBestyn(bestyn);
        adminProductVO.setImage(image);


        AdminProductDAO adminProductDAO = AdminProductDAO.getInstance();
        adminProductDAO.insertProduct(adminProductVO);




        // 상품 목록 페이지로 포워딩
        RequestDispatcher dispatcher = req.getRequestDispatcher(url);
        dispatcher.forward(req, resp);
    }
}