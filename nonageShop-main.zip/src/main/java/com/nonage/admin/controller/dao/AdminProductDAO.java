package com.nonage.admin.controller.dao;

import com.nonage.admin.controller.dto.AdminProductVO;
import util.DBManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class AdminProductDAO {

    private AdminProductDAO() {}

    private static AdminProductDAO instance = new AdminProductDAO();

    public static AdminProductDAO getInstance() {
        return instance;
    }

    // 상품 목록 조회
    public ArrayList<AdminProductVO> listProduct() {
        ArrayList<AdminProductVO> productList = new ArrayList<>();
        String sql = "SELECT pseq, name, price1, price2, indate, useyn FROM product ORDER BY pseq DESC";

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBManager.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                AdminProductVO adminProductVO = new AdminProductVO();
                adminProductVO.setPseq(rs.getInt("pseq"));
                adminProductVO.setName(rs.getString("name"));
                adminProductVO.setPrice1(rs.getInt("price1"));
                adminProductVO.setPrice2(rs.getInt("price2"));
                adminProductVO.setIndate(rs.getTimestamp("indate"));
                adminProductVO.setUseyn(rs.getString("useyn"));

                productList.add(adminProductVO);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(conn, pstmt, rs);
        }

        return productList;
    }

    // 특정 상품 정보 가져오기
    public AdminProductVO getProduct(String pseq) {
        AdminProductVO adminProductVO = null;
        String sql = "SELECT * FROM product WHERE pseq = ?";

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBManager.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, pseq);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                adminProductVO = new AdminProductVO();
                adminProductVO.setPseq(rs.getInt("pseq"));
                adminProductVO.setName(rs.getString("name"));
                adminProductVO.setKind(rs.getString("kind"));
                adminProductVO.setPrice1(rs.getInt("price1"));
                adminProductVO.setPrice2(rs.getInt("price2"));
                adminProductVO.setPrice3(rs.getInt("price3"));
                adminProductVO.setContent(rs.getString("content"));
                adminProductVO.setImage(rs.getString("image"));
                adminProductVO.setUseyn(rs.getString("useyn"));
                adminProductVO.setBestyn(rs.getString("bestyn"));
                adminProductVO.setIndate(rs.getTimestamp("indate"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(conn, pstmt, rs);
        }

        return adminProductVO;
    }

    // 상품 업데이트 메서드
    public void updateProduct(AdminProductVO adminProductVO) {
        String sql = "update product set name = ?, kind = ?, price1 = ?, price2 = ?, price3 = ?, " +
                "content = ?, image = ?, useyn = ?, bestyn = ? where pseq = ?";

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DBManager.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, adminProductVO.getName());
            pstmt.setString(2, adminProductVO.getKind());
            pstmt.setInt(3, adminProductVO.getPrice1());
            pstmt.setInt(4, adminProductVO.getPrice2());
            pstmt.setInt(5, adminProductVO.getPrice3());
            pstmt.setString(6, adminProductVO.getContent());
            pstmt.setString(7, adminProductVO.getImage());
            pstmt.setString(8, adminProductVO.getUseyn());
            pstmt.setString(9, adminProductVO.getBestyn());
            pstmt.setInt(10, adminProductVO.getPseq());

            pstmt.executeUpdate();

        }catch(Exception e) {
            e.printStackTrace();
        }finally {
            DBManager.close(conn, pstmt);
        }
    }

    // 상품 추가 메서드
    public void insertProduct(AdminProductVO adminProductVO) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        // pseq 자동 증가 처리에 대해 처리하지 않으려면 이 방식으로 계속하셔도 됩니다.
        String getMaxPseqSql = "SELECT MAX(pseq) FROM product";  // 현재 가장 큰 pseq 값을 가져오는 쿼리
        String insertSql = "INSERT INTO product (pseq, kind, name, price1, price2, price3, content, image, useyn, bestyn) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            conn = DBManager.getConnection();

            // 먼저 현재 가장 큰 pseq 값을 가져오기
            pstmt = conn.prepareStatement(getMaxPseqSql);
            rs = pstmt.executeQuery();

            int pseq = 0;  // pseq의 기본 값으로 0 설정

            // 결과가 있을 경우, 가장 큰 pseq 값에 1을 더하여 새로운 pseq 계산
            if (rs.next()) {
                pseq = rs.getInt(1);  // 가장 큰 pseq 값 가져오기
                pseq = (pseq == 0) ? 1 : pseq + 1;  // 값이 0일 경우 1로 설정 (첫 번째 삽입 시)
            }

            // Insert 쿼리 실행
            pstmt.close();  // 기존 pstmt를 닫고 새로운 pstmt 객체를 준비
            pstmt = conn.prepareStatement(insertSql);
            pstmt.setInt(1, pseq);  // 자동 증가로 변경할 경우 이 줄을 삭제하고 DB에 맡겨도 됩니다.
            pstmt.setString(2, adminProductVO.getKind());
            pstmt.setString(3, adminProductVO.getName());
            pstmt.setInt(4, adminProductVO.getPrice1());
            pstmt.setInt(5, adminProductVO.getPrice2());
            pstmt.setInt(6, adminProductVO.getPrice3());
            pstmt.setString(7, adminProductVO.getContent());
            pstmt.setString(8, adminProductVO.getImage());
            pstmt.setString(9, adminProductVO.getUseyn());
            pstmt.setString(10, adminProductVO.getBestyn());

            pstmt.executeUpdate();  // 상품 삽입
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(conn, pstmt, rs);  // 연결과 자원을 해제
        }
    }

    public ArrayList<AdminProductVO> searchAdminProductByPName(String pname) {
        ArrayList<AdminProductVO> productList = new ArrayList<>();
        String sql = "SELECT pseq, name, price1, price2, indate, useyn FROM product WHERE name LIKE ?";

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DBManager.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, "%" + pname + "%");  // pname을 포함하는 상품 검색
            rs = pstmt.executeQuery();

            while (rs.next()) {
                AdminProductVO adminProductVO = new AdminProductVO();
                adminProductVO.setPseq(rs.getInt("pseq"));
                adminProductVO.setName(rs.getString("name"));
                adminProductVO.setPrice1(rs.getInt("price1"));
                adminProductVO.setPrice2(rs.getInt("price2"));
                adminProductVO.setIndate(rs.getTimestamp("indate"));
                adminProductVO.setUseyn(rs.getString("useyn"));

                productList.add(adminProductVO);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(conn, pstmt, rs);
        }

        return productList;
    }

}
