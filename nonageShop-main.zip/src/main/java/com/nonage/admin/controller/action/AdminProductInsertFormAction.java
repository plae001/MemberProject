package com.nonage.admin.controller.action;

import com.nonage.admin.controller.dto.AdminVO;
import com.nonage.controller.action.Action;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class AdminProductInsertFormAction implements Action {
    @Override
    public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url = "admin/product/admin_product_insert.jsp";  // 상품 등록 폼


        HttpSession session = req.getSession();
        AdminVO adminLoginUser  = (AdminVO) session.getAttribute("adminLoginUser");

        // 로그인되지 않은 경우 로그인 페이지로 리다이렉트
        if (adminLoginUser  == null) {

            url = "NonageServlet?command=admin_login_form";  // 로그인 페이지로 이동

        }


        RequestDispatcher dispatcher = req.getRequestDispatcher(url);
        dispatcher.forward(req, resp);
    }
}
