package com.nonage.dto;

import lombok.Data;

@Data
public class AddressVO {

    private String zipNum;
    private String sido;
    private String gugun;
    private String dong;
    private String zipCode;
    private String bunji;
}
